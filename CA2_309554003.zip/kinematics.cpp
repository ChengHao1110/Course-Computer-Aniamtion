#include "simulation/kinematics.h"

#include "Eigen/Dense"

#include "acclaim/bone.h"
#include "util/helper.h"

#include <queue>
#include <math.h>
#include <iostream>

namespace kinematics {
void forwardSolver(const acclaim::Posture& posture, acclaim::Bone* bone) {
    // TODO
    // This function will be called with bone == root bone of the skeleton
    // You should set these variables:
    //     bone->start_position = Eigen::Vector4d::Zero();
    //     bone->end_position = Eigen::Vector4d::Zero();
    //     bone->rotation = Eigen::Matrix4d::Zero();
    // The sample above just set everything to zero

    //set root bone
    int id = bone->idx;
    bone->start_position = posture.bone_translations[id];
    bone->end_position = posture.bone_translations[id];
    bone->rotation = util::rotateDegreeZYX(posture.bone_rotations[id]).matrix();
    
    //set another bone
    //push root child to the queue
    std::queue< acclaim::Bone* > body;
    body.push(bone->child); 

    while (!body.empty()) {
        acclaim::Bone* cur = body.front();
        //get id
        id = cur->idx;
        //set the bone transform, rotation
        cur->start_position = cur->parent->end_position;
        cur->rotation = (cur->parent->rotation * cur->rot_parent_current * util::rotateDegreeZYX(posture.bone_rotations[id])).matrix();
        cur->end_position = cur->start_position + cur->length * (cur->rotation * cur->dir);
        //get next child or sibling
        if (cur->child) {
            body.push(cur->child);
        }
        if (cur->sibling) {
            body.push(cur->sibling);
        }
        //this bone is finished
        body.pop();
    }
}


std::vector<acclaim::Posture> timeWarper(const std::vector<acclaim::Posture>& postures, int keyframe_old,
                                         int keyframe_new) {
    int total_frames = static_cast<int>(postures.size());
    int total_bones = static_cast<int>(postures[0].bone_rotations.size());
    std::vector<acclaim::Posture> new_postures = postures;
    for (int i = 0; i < total_frames; ++i) {
        for (int j = 0; j < total_bones; ++j) {
            // TODO
            // You should set these variables:
            //     new_postures[i].bone_translations[j] = postures[i].bone_translations[j];
            //     new_postures[i].bone_rotations[j] = postures[i].bone_rotations[j];
            // The sample above just change nothing
            
            float ratio1 = (float)keyframe_old / keyframe_new; // 0 -> keyframe_new - 1
            float ratio2 = (float)(total_frames - keyframe_old) / (total_frames - keyframe_new); // keyframe_new -> finish

            // 0 -> keyframe_new - 1
            if ( i < keyframe_new) {
                //compute the frame
                float frame = i * ratio1;
                int frame_int = floor(frame);
                int frame_int_next = frame_int + 1;
                float frame_dem = frame - frame_int;

                //linear interpolation on translation
                //pos[frame_int] + frame_dem * (pos[frame_int_next] - pos[frame_int])
                Eigen::Vector4d diff = postures[frame_int_next].bone_translations[j] - postures[frame_int].bone_translations[j]; 
                new_postures[i].bone_translations[j] = postures[frame_int].bone_translations[j] + frame_dem * diff;
                
                //test for linear interpolation on rotation
                /*
                diff = postures[frame_int_next].bone_rotations[j] - postures[frame_int].bone_rotations[j];
                new_postures[i].bone_rotations[j] = postures[frame_int].bone_rotations[j] + frame_dem * diff;
                */
                
                //slerp on rotation
                //reference: https://tigercosmos.xyz/post/2020/05/ca/forward-kinematics-time-warping/
                //auto rot1 = ComputeRotMatXyz(ToRadian(angular_vector1);
                //auto rot2 = ComputeRotMatXyz(ToRadian(angular_vector2));
                //auto q1 = Quaternion_t(rot1);
                //auto q2 = Quaternion_t(rot2);
                //auto new_q = Slerp(q1, q2, ratio);
                //auto new_angular_vec = ToDegree(ComputeEulerAngleXyz(ComputeRotMat(new_q)));
                
                Eigen::Vector4d rot = postures[frame_int].bone_rotations[j];
                Eigen::Vector4d rot_next = postures[frame_int_next].bone_rotations[j]; 
                //get Quaterion
                Eigen::Quaterniond rot_q = util::rotateRadianZYX( util::toRadian(rot) );
                Eigen::Quaterniond rot_next_q = util::rotateRadianZYX( util::toRadian(rot_next) );
                //slerp function
                Eigen::Quaterniond slerp = rot_q.slerp(frame_dem, rot_next_q);

                //rotate matrix (degree)
                Eigen::Vector3d rot_mat = slerp.normalized().toRotationMatrix().eulerAngles(2,1,0).reverse();
                Eigen::Vector4d rot_matrix(rot_mat.x(), rot_mat.y(), rot_mat.z(), 0);
                rot_matrix = util::toDegree(rot_matrix);
                new_postures[i].bone_rotations[j] = rot_matrix;
                
            }
            // keyframe_new -> total_frame - 1
            else {         
                //compute the frame
                float frame = keyframe_old + (i - keyframe_new) * ratio2;
                int frame_int = floor(frame);
                int frame_int_next = frame_int + 1;
                float frame_dem = frame - frame_int;

                //last frame
                if (frame > total_frames - 1) {
                    new_postures[i].bone_translations[j] = postures[frame_int].bone_translations[j];
                    new_postures[i].bone_rotations[j] = postures[frame_int].bone_rotations[j];
                }
                //not last frame 
                else {
                    //linear interpolation on translation
                    //pos[frame_int] + frame_dem * (pos[frame_int_next] - pos[frame_int])
                    Eigen::Vector4d diff = postures[frame_int_next].bone_translations[j] - postures[frame_int].bone_translations[j];
                    new_postures[i].bone_translations[j] = postures[frame_int].bone_translations[j] + frame_dem * diff;

                    //test for linear interpolation on rotation
                    /*
                    diff = postures[frame_int_next].bone_rotations[j] - postures[frame_int].bone_rotations[j];
                    new_postures[i].bone_rotations[j] = postures[frame_int].bone_rotations[j] + frame_dem * diff;
                    */
                    
                    //slerp on rotation
                    Eigen::Vector4d rot = postures[frame_int].bone_rotations[j];
                    Eigen::Vector4d rot_next = postures[frame_int_next].bone_rotations[j];
                    //get Quaterion
                    Eigen::Quaterniond rot_q = util::rotateRadianZYX(util::toRadian(rot));
                    Eigen::Quaterniond rot_next_q = util::rotateRadianZYX(util::toRadian(rot_next));
                    //slerp function
                    Eigen::Quaterniond slerp = rot_q.slerp(frame_dem, rot_next_q);

                    //rotate matrix (degree)
                    Eigen::Vector3d rot_mat = slerp.normalized().toRotationMatrix().eulerAngles(2, 1, 0).reverse();
                    Eigen::Vector4d rot_matrix(rot_mat.x(), rot_mat.y(), rot_mat.z(), 0);
                    rot_matrix = util::toDegree(rot_matrix);
                    new_postures[i].bone_rotations[j] = rot_matrix;
                    
                }
            }
        }
    }
    return new_postures;
}
}  // namespace kinematics
